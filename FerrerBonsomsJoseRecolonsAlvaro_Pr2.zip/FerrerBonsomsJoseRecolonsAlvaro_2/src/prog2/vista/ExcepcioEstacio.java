package prog2.vista;

public class ExcepcioEstacio extends Exception {

}
